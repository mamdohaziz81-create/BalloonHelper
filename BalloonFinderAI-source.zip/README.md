# Balloon Finder AI

Android prototype for Android 8+ (target SDK 35). It captures the screen with the user's permission and draws a non-touchable transparent overlay. It does not tap, swipe, or control the game.

## Build APK
Open this project in Android Studio (Ladybug or newer), allow Gradle sync, then run:
`./gradlew assembleDebug`

The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
This first prototype uses on-device color-connected-component heuristics to group similarly colored, similarly proportioned objects. It is **not** a trained visual model and has not been validated against every level or camera angle of Balloon Master 3D. 3D occlusion, overlapping balloons, lighting, and game UI can cause missed or incorrect circles. Treat the circles as suggestions, not guaranteed exact matches. The user must rotate the board to reveal hidden objects.

Screen capture requires the Android system's one-time screen-sharing consent each time the service starts, and overlay permission must be granted manually.

package com.balloonfinder.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.view.WindowManager.LayoutParams
import java.util.ArrayDeque
import kotlin.math.abs
import kotlin.math.max

class CaptureOverlayService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "capture_result_code"
        const val EXTRA_RESULT_DATA = "capture_result_data"
        private const val CHANNEL_ID = "balloon_finder_capture"
        private const val NOTIFICATION_ID = 77
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var overlay: MatchOverlay? = null
    private var windowManager: WindowManager? = null
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var screenWidth = 0
    private var screenHeight = 0
    private var lastAnalysis = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (data == null || resultCode == 0) {
            stopSelf()
            return START_NOT_STICKY
        }
        startCapture(resultCode, data)
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        windowManager?.defaultDisplay?.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels

        overlay = MatchOverlay(this, screenWidth, screenHeight)
        val params = LayoutParams(
            LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_NOT_TOUCHABLE or
                LayoutParams.FLAG_LAYOUT_IN_SCREEN or LayoutParams.FLAG_LAYOUT_NO_LIMIT,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        windowManager?.addView(overlay, params)

        worker = HandlerThread("balloon-frame-worker").also { it.start() }
        workerHandler = Handler(worker!!.looper)

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, workerHandler)

        reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            var image: Image? = null
            try {
                image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
                val now = System.currentTimeMillis()
                if (now - lastAnalysis < 650) return@setOnImageAvailableListener
                lastAnalysis = now
                val bitmap = imageToBitmap(image)
                val matches = BalloonDetector.findMatches(bitmap)
                val sx = screenWidth.toFloat() / BalloonDetector.WORK_WIDTH
                val sy = screenHeight.toFloat() / BalloonDetector.workHeight(screenWidth, screenHeight)
                overlay?.post { overlay?.setMatches(matches, sx, sy) }
                bitmap.recycle()
            } catch (_: Exception) {
            } finally {
                image?.close()
            }
        }, workerHandler)

        virtualDisplay = projection?.createVirtualDisplay(
            "BalloonFinderScreen",
            screenWidth, screenHeight, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, workerHandler
        )
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(plane.buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Balloon Finder", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Balloon Finder AI يعمل")
                .setContentText("تحليل الشاشة وتحديد الأشكال المتشابهة")
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Balloon Finder AI يعمل")
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .build()
        }
    }

    override fun onDestroy() {
        try { windowManager?.removeView(overlay) } catch (_: Exception) {}
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        worker?.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

private data class MatchCircle(val x: Float, val y: Float, val radius: Float, val count: Int)

private class MatchOverlay(context: Context, private val widthPx: Int, private val heightPx: Int) : View(context) {
    private val circles = mutableListOf<MatchCircle>()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(40, 255, 100)
        style = Paint.Style.STROKE
        strokeWidth = 7f
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 34f
        style = Paint.Style.FILL
        setShadowLayer(5f, 1f, 1f, Color.BLACK)
    }

    fun setMatches(items: List<MatchCircle>, sx: Float, sy: Float) {
        circles.clear()
        items.forEach { circles.add(MatchCircle(it.x * sx, it.y * sy, it.radius * max(sx, sy), it.count)) }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        circles.forEach {
            canvas.drawCircle(it.x, it.y, it.radius, line)
            canvas.drawText("x${it.count}", it.x - 22f, it.y - it.radius - 8f, label)
        }
    }
}

private object BalloonDetector {
    const val WORK_WIDTH = 300
    private data class Blob(val x: Float, val y: Float, val w: Float, val h: Float, val hueBin: Int, val aspectBin: Int)

    fun workHeight(w: Int, h: Int): Int = (WORK_WIDTH.toFloat() * h / w).toInt().coerceAtLeast(1)

    fun findMatches(source: Bitmap): List<MatchCircle> {
        val targetH = workHeight(source.width, source.height)
        val small = Bitmap.createScaledBitmap(source, WORK_WIDTH, targetH, true)
        val pixels = IntArray(WORK_WIDTH * targetH)
        small.getPixels(pixels, 0, WORK_WIDTH, 0, 0, WORK_WIDTH, targetH)
        small.recycle()

        val hsv = FloatArray(3)
        val hue = FloatArray(pixels.size)
        val sat = FloatArray(pixels.size)
        val valc = FloatArray(pixels.size)
        val candidate = BooleanArray(pixels.size)
        for (i in pixels.indices) {
            Color.colorToHSV(pixels[i], hsv)
            hue[i] = hsv[0]
            sat[i] = hsv[1]
            valc[i] = hsv[2]
            candidate[i] = hsv[1] > 0.48f && hsv[2] > 0.24f && hsv[2] < 0.98f
        }

        val seen = BooleanArray(pixels.size)
        val blobs = mutableListOf<Blob>()
        val queue = ArrayDeque<Int>()
        for (start in pixels.indices) {
            if (!candidate[start] || seen[start]) continue
            val seedHue = hue[start]
            queue.clear()
            queue.add(start)
            seen[start] = true
            var minX = WORK_WIDTH; var maxX = 0; var minY = targetH; var maxY = 0
            var count = 0
            while (queue.isNotEmpty() && count < 12000) {
                val p = queue.removeFirst()
                val x = p % WORK_WIDTH
                val y = p / WORK_WIDTH
                count++
                minX = minOf(minX, x); maxX = maxOf(maxX, x)
                minY = minOf(minY, y); maxY = maxOf(maxY, y)
                val ns = intArrayOf(
                    if (x > 0) p - 1 else -1,
                    if (x < WORK_WIDTH - 1) p + 1 else -1,
                    if (y > 0) p - WORK_WIDTH else -1,
                    if (y < targetH - 1) p + WORK_WIDTH else -1
                )
                for (n in ns) {
                    if (n < 0 || seen[n] || !candidate[n]) continue
                    val hd = abs(hue[n] - seedHue).let { minOf(it, 360f - it) }
                    if (hd <= 17f && abs(sat[n] - sat[start]) < 0.42f) {
                        seen[n] = true
                        queue.add(n)
                    }
                }
            }
            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            val aspect = bw.toFloat() / bh.coerceAtLeast(1)
            if (count in 35..3500 && bw >= 5 && bh >= 7 && aspect in 0.48f..1.65f) {
                blobs.add(Blob((minX + maxX) / 2f, (minY + maxY) / 2f, bw.toFloat(), bh.toFloat(),
                    (seedHue / 30f).toInt(), (aspect * 4).toInt()))
            }
        }

        val groups = blobs.groupBy { it.hueBin to it.aspectBin }
        val output = mutableListOf<MatchCircle>()
        for (group in groups.values) {
            if (group.size < 3) continue
            group.forEach { b ->
                output.add(MatchCircle(b.x, b.y, max(b.w, b.h) * 0.68f, group.size))
            }
        }
        return output
    }
}

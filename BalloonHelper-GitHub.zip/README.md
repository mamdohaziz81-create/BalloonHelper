# Balloon Helper APK

This repository contains the GitHub Actions workflow that generates the Android project
and builds a debug APK.

## Build
1. Upload the contents of this ZIP to the root of a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build APK**, then choose **Run workflow**.
4. When the run finishes, open it and download the **BalloonHelper** artifact.
5. Extract the artifact ZIP; it contains `app-debug.apk`.

The workflow creates the Android source files during the run. The APK is a debug build,
not a Play Store release.
